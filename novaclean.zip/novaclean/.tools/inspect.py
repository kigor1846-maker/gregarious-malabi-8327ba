from PIL import Image
import os

base = r"C:\Users\kigor\OneDrive\Desktop\проеты\bl deyteinng\novaclean\.tools\img"

for name, axis in [("img3.jpg", "y"), ("img4.jpg", "x")]:
    im = Image.open(os.path.join(base, name)).convert("RGB")
    w, h = im.size
    print(name, im.size)
    if axis == "y":
        for y in range(int(h * 0.45), int(h * 0.56)):
            row = [im.getpixel((x, y)) for x in range(0, w, 7)]
            m = sum(sum(p) / 3 for p in row) / len(row)
            if m > 235:
                print("  bright row", y, round(m, 1))
    else:
        for x in range(int(w * 0.45), int(w * 0.56)):
            col = [im.getpixel((x, y)) for y in range(0, h, 7)]
            m = sum(sum(p) / 3 for p in col) / len(col)
            if m > 235:
                print("  bright col", x, round(m, 1))

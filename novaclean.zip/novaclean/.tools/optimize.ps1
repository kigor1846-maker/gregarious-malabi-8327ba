Add-Type -AssemblyName System.Drawing

$root = "C:\Users\kigor\OneDrive\Desktop\проеты\bl deyteinng\novaclean"
$img = Join-Path $root ".tools\img"
$out = Join-Path $root ".tools\opt"
New-Item -ItemType Directory -Force -Path $out | Out-Null

function Save-Jpeg {
  param([System.Drawing.Bitmap]$bmp, [string]$path, [int]$quality = 82)
  $codec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq 'image/jpeg' }
  $enc = [System.Drawing.Imaging.Encoder]::Quality
  $pars = New-Object System.Drawing.Imaging.EncoderParameters(1)
  $pars.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter($enc, [long]$quality)
  $bmp.Save($path, $codec, $pars)
  $pars.Dispose()
}

function Resize-To {
  param([System.Drawing.Image]$source, [int]$maxSide)
  $k = [Math]::Min(1.0, $maxSide / [Math]::Max($source.Width, $source.Height))
  $w = [int][Math]::Round($source.Width * $k)
  $h = [int][Math]::Round($source.Height * $k)
  $bmp = New-Object System.Drawing.Bitmap($w, $h)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
  $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
  $g.DrawImage($source, 0, 0, $w, $h)
  $g.Dispose()
  return $bmp
}

function Crop-To {
  param([System.Drawing.Image]$source, [int]$x, [int]$y, [int]$w, [int]$h)
  $bmp = New-Object System.Drawing.Bitmap($w, $h)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $g.DrawImage($source, (New-Object System.Drawing.Rectangle(0, 0, $w, $h)), (New-Object System.Drawing.Rectangle($x, $y, $w, $h)), [System.Drawing.GraphicsUnit]::Pixel)
  $g.Dispose()
  return $bmp
}

# герой и баннер
$hero = [System.Drawing.Image]::FromFile((Join-Path $img "img1.jpg"))
$hb = Resize-To $hero 900
Save-Jpeg $hb (Join-Path $out "hero.jpg") 80
$hb.Dispose(); $hero.Dispose()

$ban = [System.Drawing.Image]::FromFile((Join-Path $img "img2.jpg"))
$bb = Resize-To $ban 1000
Save-Jpeg $bb (Join-Path $out "banner.jpg") 80
$bb.Dispose(); $ban.Dispose()

# пара A: верх / низ
$a = [System.Drawing.Image]::FromFile((Join-Path $img "img3.jpg"))
$mid = [int]($a.Height / 2)
$a1 = Crop-To $a 0 0 $a.Width ($mid - 4)
$a2 = Crop-To $a 0 ($mid + 4) $a.Width ($a.Height - $mid - 4)
Save-Jpeg $a1 (Join-Path $out "a1.jpg") 82
Save-Jpeg $a2 (Join-Path $out "a2.jpg") 82
$a1.Dispose(); $a2.Dispose(); $a.Dispose()

# пара B: лево / право, шов примерно по центру
$b = [System.Drawing.Image]::FromFile((Join-Path $img "img4.jpg"))
$cx = [int]($b.Width / 2)
$b1 = Crop-To $b 0 0 ($cx - 6) $b.Height
$b2 = Crop-To $b ($cx + 6) 0 ($b.Width - $cx - 6) $b.Height
Save-Jpeg $b1 (Join-Path $out "b1.jpg") 82
Save-Jpeg $b2 (Join-Path $out "b2.jpg") 82
$b1.Dispose(); $b2.Dispose(); $b.Dispose()

Get-ChildItem -LiteralPath $out | ForEach-Object {
  $im = [System.Drawing.Image]::FromFile($_.FullName)
  "{0}: {1} KB, {2}x{3}" -f $_.Name, [math]::Round($_.Length / 1KB, 1), $im.Width, $im.Height
  $im.Dispose()
}

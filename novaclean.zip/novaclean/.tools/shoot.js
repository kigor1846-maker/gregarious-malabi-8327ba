const { chromium } = require('playwright-core');
const path = require('path');
const fs = require('fs');

const exe = 'C:/Users/kigor/AppData/Local/ms-playwright/chromium-1228/chrome-win64/chrome.exe';
const file = process.argv[2];
const outDir = process.argv[3] || path.join(__dirname, 'shots');
fs.mkdirSync(outDir, { recursive: true });

(async () => {
  const browser = await chromium.launch({ executablePath: exe });
  const results = [];
  for (const [name, width, height] of [['desktop', 1440, 1000], ['mobile', 390, 844]]) {
    const ctx = await browser.newContext({ viewport: { width, height }, deviceScaleFactor: 1 });
    const page = await ctx.newPage();
    const logs = [];
    page.on('console', m => logs.push(`[${m.type()}] ${m.text()}`));
    page.on('pageerror', e => logs.push(`[pageerror] ${e.message}`));
    await page.goto('file:///' + file.replace(/\\/g, '/'), { waitUntil: 'load' });
    await page.waitForTimeout(1200);
    const full = path.join(outDir, `${name}-site.png`);
    await page.screenshot({ path: full, fullPage: true });
    // admin
    await page.evaluate(() => { document.getElementById('tabAdmin').click(); });
    await page.waitForTimeout(600);
    const admin = path.join(outDir, `${name}-admin.png`);
    await page.screenshot({ path: admin, fullPage: true });
    const metrics = await page.evaluate(() => {
      const de = document.documentElement;
      return {
        scrollW: de.scrollWidth, clientW: de.clientWidth,
        bodyH: de.scrollHeight,
        overflowX: de.scrollWidth > de.clientWidth + 1,
        adminVisible: !document.getElementById('admin').classList.contains('hidden'),
        kanbanCards: document.querySelectorAll('#kanban .lead-card').length,
        price: document.getElementById('price').textContent,
        leads: (() => { try { return JSON.parse(localStorage.getItem('nc_leads') || '[]').length } catch (e) { return 'err' } })(),
        tabs: [...document.querySelectorAll('#atabs button')].map(b => b.textContent.trim()),
      };
    });
    results.push({ name, logs, metrics });
    await ctx.close();
  }
  await browser.close();
  console.log(JSON.stringify(results, null, 2));
})().catch(e => { console.error('FATAL', e); process.exit(1); });

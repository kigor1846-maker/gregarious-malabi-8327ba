'use strict';
/* ============================================================
   NovaClean v5 — сайт + кабинет в одном файле
   Данные: IndexedDB (заявки, фото, настройки), fallback localStorage
   ============================================================ */

/* ---------- Уведомления (необязательно) ----------
   Чтобы заявки приходили автоматически, впишите сюда данные.
   ВНИМАНИЕ: файл публичный, токен будет виден в исходном коде.
   Для боевого сайта перенесите отправку на сервер.
   Telegram: создайте бота у @BotFather, узнайте chat_id у @userinfobot.
   E-mail: зарегистрируйте адрес на formsubmit.co и вставьте ссылку вида
   https://formsubmit.co/ajax/you@mail.ru
--------------------------------------------------- */
const NC_DELIVERY = {
  telegram: { token: '', chatId: '' },
  email: { endpoint: '' }
};

const IMG = {
  a1: '{{IMG_A1}}',
  a2: '{{IMG_A2}}',
  b1: '{{IMG_B1}}',
  b2: '{{IMG_B2}}'
};
IMG.hero = (document.getElementById('heroImg') || {}).src || '';
IMG.banner = (document.querySelector('.banner img') || {}).src || '';

const STATUSES = ['Новая', 'В обработке', 'Выехал', 'Выполнено', 'Отказ'];
const STATUS_CLASS = {
  'Новая': 'st-new',
  'В обработке': 'st-work',
  'Выехал': 'st-way',
  'Выполнено': 'st-done',
  'Отказ': 'st-cancel'
};

const TYPES = [
  { k: 'sofa', n: 'Диван', priceKey: 'sofa', sizes: true },
  { k: 'chair', n: 'Кресло', priceKey: 'chair', sizes: false },
  { k: 'mat', n: 'Матрас', priceKey: 'mat', sizes: true },
  { k: 'carpet', n: 'Ковёр', priceKey: 'carpetM2', sizes: false }
];

const SIZE_LABELS = {
  sofa: ['2 места', '3 места', 'Угловой'],
  mat: ['Односпальный', 'Двуспальный', 'Большой']
};

const STAINS = [
  { k: 'food', n: 'Еда, соки', hint: 'обычно выводится за один проход' },
  { k: 'coffee', n: 'Кофе, вино', hint: 'старые пятна могут оставить бледный след' },
  { k: 'grease', n: 'Жир, масло', hint: 'нужен отдельный состав для жира' },
  { k: 'urine', n: 'Моча, запах', hint: 'нужна обработка от запаха, возможно два прохода' },
  { k: 'ink', n: 'Ручка, краска', hint: 'полный результат не гарантирован — мастер оценит по фото' },
  { k: 'mold', n: 'Плесень', hint: 'нужны сушка и антисептик, предупредите заранее' }
];

const DIRT_LABELS = ['Лёгкое', 'Среднее', 'Сильное'];

const DEFAULT_GALLERY = [
  { id: 'g1', mode: 'pair', before: '@a1', after: '@a2', cap: 'Угловой диван, сильные загрязнения' },
  { id: 'g2', mode: 'pair', before: '@b1', after: '@b2', cap: 'Диван, разводы после залива' }
];

const DEFAULT_SETTINGS = {
  brand: {
    name: 'NovaClean',
    phone: '+7 900 000-00-00',
    wa: '',
    tg: 'novaclean',
    max: '',
    cities: 'по городу и пригороду',
    hours: 'ежедневно 8:00–22:00',
    color: '#14804a',
    logo: '',
    foot: 'Химчистка мягкой мебели на дому. Цена предварительная, точную стоимость называет мастер после осмотра.'
  },
  prices: { sofa: 3500, chair: 1200, mat: 2500, carpetM2: 350 },
  cfg: {
    dirt: [1, 1.25, 1.5],
    sizes: { sofa: [1, 1.3, 1.8], mat: [0.8, 1, 1.3] },
    stains: { food: 0, coffee: 0.1, grease: 0.1, urine: 0.2, ink: 0.15, mold: 0.25 },
    hiNorm: 1.2,
    hiHard: 1.35
  },
  texts: {
    h1: 'Химчистка диванов, матрасов и ковров *на дому*',
    sub: 'Профессиональная чистка мягкой мебели без переезда: приезжаем со своим оборудованием, работаем аккуратно и убираем за собой.',
    perks: [
      { t: 'Сухой туман в подарок', d: 'Диван пахнет свежестью, а не химией' },
      { t: 'Оборудование Kärcher', d: 'Вытягивает грязь из глубины, а не гоняет по поверхности' },
      { t: 'Выезд на дом', d: 'Приезжаем сами — мебель никуда везти не нужно' },
      { t: 'Оплата как удобно', d: 'Картой, по СБП или наличными мастеру' }
    ],
    steps: [
      { t: 'Вы отправляете заявку', d: 'Можно с фото — так мы точнее оценим работу' },
      { t: 'Называем точную цену', d: 'До выезда, без скрытых доплат' },
      { t: 'Мастер приезжает', d: 'Со своим оборудованием и химией, в удобное время' },
      { t: 'Принимаете работу', d: 'Проверяете результат и платите после' }
    ],
    reviews: [
      { n: 'Ксения, ЖК «Северный парк»', t: 'Почистили угловой диван после детей. Пятна от сока ушли, запаха нет. Мастер приехал вовремя.' },
      { n: 'Игорь, мкр Новая Деревня', t: 'Заказал матрас и два кресла. Прислал фото, цену назвали сразу и не изменили.' },
      { n: 'Алина, ЖК «Речной»', t: 'Оплатила по СБП мастеру на месте. Ковёр высох за день, цвета стали ярче.' },
      { n: 'Денис, Центральный район', t: 'Приятно, что сухой туман дали в подарок. Теперь вызываю раз в год.' }
    ],
    faq: [
      { q: 'Сколько сохнет мебель?', a: 'Обычно 6–12 часов. Время зависит от ткани, толщины наполнителя и проветривания. К вечеру диван уже можно использовать.' },
      { q: 'Нужно ли что-то готовить к приезду мастера?', a: 'Освободите подход к мебели, уберите мелкие вещи и обеспечьте доступ к розетке 220 В. Подушки и съёмные чехлы лучше снять заранее.' },
      { q: 'Все ли пятна можно вывести?', a: 'Большинство бытовых загрязнений — да. Краска, маркер, старые пятна и плесень могут оставить след: мастер оценит по фото и честно скажет, на какой результат рассчитывать.' },
      { q: 'Безопасно ли для детей и животных?', a: 'Мы используем профессиональные составы и тщательно вымываем их экстрактором. После высыхания мебель безопасна. Сообщите об аллергии или чувствительности заранее.' },
      { q: 'Как считается цена?', a: 'Базовая цена за предмет плюс коэффициент загрязнения и надбавки за сложные пятна. Калькулятор показывает вилку, точную сумму называем по фото или при осмотре.' },
      { q: 'Как можно оплатить?', a: 'Картой, по СБП или наличными мастеру после работы. Чек предоставляем.' }
    ]
  },
  photos: { hero: '', banner: '', gallery: null },
  security: { pin: '' }
};

/* ---------- Утилиты ---------- */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const clone = (v) => JSON.parse(JSON.stringify(v));
const digits = (v) => String(v == null ? '' : v).replace(/\D/g, '');
const money = (n) => new Intl.NumberFormat('ru-RU').format(Math.round(Number(n) || 0)) + ' ₽';
const num = (v, d = 0) => {
  const n = parseFloat(String(v == null ? '' : v).replace(',', '.'));
  return Number.isFinite(n) ? n : d;
};
const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function deepMerge(base, extra) {
  if (Array.isArray(base)) return Array.isArray(extra) ? extra : base;
  if (base && typeof base === 'object') {
    const out = {};
    const keys = new Set([...Object.keys(base), ...Object.keys(extra || {})]);
    keys.forEach((k) => { out[k] = deepMerge(base[k], extra ? extra[k] : undefined); });
    return out;
  }
  return extra === undefined ? base : extra;
}

function setPath(obj, path, value) {
  const parts = path.split('.');
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    const key = parts[i];
    if (cur[key] == null || typeof cur[key] !== 'object') cur[key] = /^\d+$/.test(parts[i + 1]) ? [] : {};
    cur = cur[key];
  }
  cur[parts[parts.length - 1]] = value;
}

function resolveImg(src) {
  if (!src) return '';
  return src.charAt(0) === '@' ? (IMG[src.slice(1)] || '') : src;
}

function timeAgo(ts) {
  const diff = Date.now() - (Number(ts) || Date.now());
  const m = Math.round(diff / 60000);
  if (m < 1) return 'только что';
  if (m < 60) return m + ' мин назад';
  const h = Math.round(m / 60);
  if (h < 24) return h + ' ч назад';
  const d = Math.round(h / 24);
  if (d === 1) return 'вчера';
  if (d < 7) return d + ' дн. назад';
  return new Date(Number(ts)).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
}

function dateFull(ts) {
  return new Date(Number(ts) || Date.now()).toLocaleString('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });
}

/* ---------- Хранилище ---------- */
const DB = (() => {
  const NAME = 'novaclean';
  const VERSION = 1;
  let promise = null;
  function open() {
    if (promise) return promise;
    promise = new Promise((resolve, reject) => {
      let req;
      try { req = indexedDB.open(NAME, VERSION); } catch (e) { return reject(e); }
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('leads')) db.createObjectStore('leads', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('kv')) db.createObjectStore('kv');
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error('indexeddb'));
      req.onblocked = () => reject(new Error('indexeddb blocked'));
    });
    return promise;
  }
  function tx(store, mode, fn) {
    return open().then((db) => new Promise((resolve, reject) => {
      let t, q;
      try {
        t = db.transaction(store, mode);
        q = fn(t.objectStore(store));
      } catch (e) { return reject(e); }
      t.oncomplete = () => resolve(q);
      t.onerror = () => reject(t.error || new Error('tx'));
      t.onabort = () => reject(t.error || new Error('abort'));
    }).then((q) => (q && 'result' in q ? q.result : q)));
  }
  return {
    open,
    getAll: (s) => tx(s, 'readonly', (st) => st.getAll()),
    get: (s, k) => tx(s, 'readonly', (st) => st.get(k)),
    put: (s, v, k) => tx(s, 'readwrite', (st) => (k === undefined ? st.put(v) : st.put(v, k))),
    del: (s, k) => tx(s, 'readwrite', (st) => st.delete(k)),
    clear: (s) => tx(s, 'readwrite', (st) => st.clear())
  };
})();

const store = {
  mode: 'idb',
  async init() {
    try { await DB.open(); } catch (e) { this.mode = 'ls'; }
    return this.mode;
  },
  async getSettings() {
    if (this.mode === 'idb') return (await DB.get('kv', 'settings')) || null;
    try { return JSON.parse(localStorage.getItem('nc5_settings') || 'null'); } catch (e) { return null; }
  },
  async putSettings(obj) {
    if (this.mode === 'idb') return DB.put('kv', obj, 'settings');
    localStorage.setItem('nc5_settings', JSON.stringify(obj));
  },
  async getPhotos() {
    if (this.mode === 'idb') return (await DB.get('kv', 'photos')) || null;
    try { return JSON.parse(localStorage.getItem('nc5_photos') || 'null'); } catch (e) { return null; }
  },
  async putPhotos(obj) {
    if (this.mode === 'idb') return DB.put('kv', obj, 'photos');
    localStorage.setItem('nc5_photos', JSON.stringify(obj));
  },
  async getMeta(k) {
    if (this.mode === 'idb') return DB.get('kv', 'meta:' + k);
    try { return JSON.parse(localStorage.getItem('nc5_meta_' + k) || 'null'); } catch (e) { return null; }
  },
  async setMeta(k, v) {
    if (this.mode === 'idb') return DB.put('kv', v, 'meta:' + k);
    localStorage.setItem('nc5_meta_' + k, JSON.stringify(v));
  },
  async getAllLeads() {
    if (this.mode === 'idb') return (await DB.getAll('leads')) || [];
    try { return JSON.parse(localStorage.getItem('nc5_leads') || '[]'); } catch (e) { return []; }
  },
  async putLead(l) {
    if (this.mode === 'idb') return DB.put('leads', l);
    const list = await this.getAllLeads();
    const i = list.findIndex((x) => x.id === l.id);
    if (i >= 0) list[i] = l; else list.unshift(l);
    localStorage.setItem('nc5_leads', JSON.stringify(list));
  },
  async delLead(id) {
    if (this.mode === 'idb') return DB.del('leads', id);
    const list = (await this.getAllLeads()).filter((x) => x.id !== id);
    localStorage.setItem('nc5_leads', JSON.stringify(list));
  },
  async clearLeads() {
    if (this.mode === 'idb') return DB.clear('leads');
    localStorage.removeItem('nc5_leads');
  },
  async getVideo() {
    if (this.mode === 'idb') return DB.get('kv', 'video');
    return null;
  },
  async putVideo(blob) {
    if (this.mode === 'idb') return DB.put('kv', blob, 'video');
    throw new Error('Видео не поддерживается в этом браузере');
  },
  async delVideo() {
    if (this.mode === 'idb') return DB.del('kv', 'video');
  }
};

/* ---------- Состояние ---------- */
let settings = clone(DEFAULT_SETTINGS);
let leads = [];
let state = { type: 'sofa', size: 0, dirt: 0, CL: 3, CW: 2, dims: '', qty: 1, stains: new Set() };
let media = [];
let adminTab = 'leads';
let adminView = 'list';
let searchQuery = '';
let statusFilter = '';
let authorized = false;
let videoUrl = null;
let saveTimer = null;

/* ---------- Миграция v4 ---------- */
async function migrateV4() {
  if (await store.getMeta('migrated')) return;
  if ((await store.getAllLeads()).length) { await store.setMeta('migrated', 1); return; }
  let s4 = null, l4 = null, p4 = null;
  try { s4 = JSON.parse(localStorage.getItem('nc_settings') || 'null'); } catch (e) {}
  try { l4 = JSON.parse(localStorage.getItem('nc_leads') || 'null'); } catch (e) {}
  try { p4 = JSON.parse(localStorage.getItem('nc_photos') || 'null'); } catch (e) {}
  if (!s4 && !l4) { await store.setMeta('migrated', 1); return; }

  if (s4) {
    const b = settings.brand;
    if (s4.company) b.name = s4.company;
    if (s4.phone) b.phone = s4.phone;
    if (s4.wa) b.wa = s4.wa;
    if (s4.tg) b.tg = s4.tg;
    if (s4.max) b.max = s4.max;
    if (s4.cities) b.cities = s4.cities;
    if (s4.color) b.color = s4.color;
    if (s4.logo) b.logo = s4.logo;
    if (s4.prices) settings.prices = Object.assign(settings.prices, s4.prices);
    if (s4.cfg && s4.cfg.dirt) settings.cfg.dirt = s4.cfg.dirt;
    if (s4.cfg && s4.cfg.hiNorm) settings.cfg.hiNorm = s4.cfg.hiNorm;
    if (s4.cfg && s4.cfg.hiHard) settings.cfg.hiHard = s4.cfg.hiHard;
    if (s4.cfg && s4.cfg.sizes) Object.assign(settings.cfg.sizes, s4.cfg.sizes);
    if (s4.cfg && s4.cfg.stains) Object.assign(settings.cfg.stains, s4.cfg.stains);
    if (s4.txt) {
      const t = s4.txt;
      if (t.h1) settings.texts.h1 = t.h1;
      if (Array.isArray(t.perks)) settings.texts.perks = t.perks.map((p) => {
        const parts = String(p).split(/:\s*/);
        return { t: parts[0] || '', d: parts.slice(1).join(': ') || '' };
      });
      if (Array.isArray(t.steps)) settings.texts.steps = t.steps.map((s) => ({ t: s, d: '' }));
      if (Array.isArray(t.reviews)) settings.texts.reviews = t.reviews.map((r) => ({ n: r[0] || '', t: r[1] || '' }));
    }
  }

  if (l4 && l4.length) {
    const existing = await store.getAllLeads();
    if (!existing.length) {
      for (let i = 0; i < l4.length; i++) {
        const l = l4[i];
        const id = Number(l.id) || Date.now() - i;
        await store.putLead({
          id,
          createdAt: Number(l.id) || Date.now() - i * 60000,
          name: l.name || '',
          phone: l.phone || '',
          contact: l.contact || 'Позвонить',
          addr: l.addr || '',
          service: l.service || '',
          price: Number(l.price) || 0,
          high: Number(l.high) || 0,
          status: STATUSES.includes(l.status) ? l.status : 'Новая',
          comment: l.comment || '',
          photos: Array.isArray(l.photos) ? l.photos.filter((p) => /^data:image\//.test(p)) : [],
          videos: Array.isArray(l.videos) ? l.videos : [],
          source: 'перенос из v4',
          delivery: []
        });
      }
    }
  }

  if (p4) {
    settings.photos.hero = /^data:image\//.test(p4.hero || '') ? p4.hero : '';
    settings.photos.banner = /^data:image\//.test(p4.banner || '') ? p4.banner : '';
    if (Array.isArray(p4.gallery) && p4.gallery.length) {
      settings.photos.gallery = p4.gallery.map((g) => {
        const imgs = Array.isArray(g.imgs) ? g.imgs : [];
        return imgs.length >= 2
          ? { id: 'g' + Math.random().toString(36).slice(2, 8), mode: 'pair', before: imgs[0], after: imgs[1], cap: g.cap || 'Работа' }
          : { id: 'g' + Math.random().toString(36).slice(2, 8), mode: 'single', before: imgs[0] || '', after: '', cap: g.cap || 'Работа' };
      });
    }
  }

  await store.putSettings(settingsWithoutPhotos());
  await store.putPhotos(settings.photos);
  await store.setMeta('migrated', 1);

  ['nc_settings', 'nc_leads', 'nc_photos', 'nc_ru', 'nc_seeded'].forEach((k) => {
    try { localStorage.removeItem(k); } catch (e) {}
  });
}

function settingsWithoutPhotos() {
  const copy = clone(settings);
  copy.photos = undefined;
  return copy;
}

/* ---------- Демо-заявки ---------- */
function demoLeads() {
  const now = Date.now();
  const base = [
    { name: 'Мария', phone: '+7 912 345-67-89', contact: 'WhatsApp', addr: 'Центральный р-н, ул. Ленина', service: 'Диван, угловой (220×90 см) × 1; загрязнение: среднее; пятна: кофе, вино', price: 8663, high: 10395, status: 'Новая', comment: 'Пролили кофе неделю назад', ago: 15 * 60000 },
    { name: 'Дмитрий', phone: '+7 903 222-33-44', contact: 'Telegram', addr: 'мкр Новая Деревня', service: 'Матрас, двуспальный × 1; загрязнение: лёгкое', price: 2500, high: 3000, status: 'В обработке', comment: '', ago: 2 * 3600000 },
    { name: 'Екатерина', phone: '+7 926 333-44-55', contact: 'Позвонить', addr: 'мкр Северный', service: 'Ковёр 3×2 м × 1; загрязнение: сильное; пятна: моча, запах', price: 3780, high: 5103, status: 'Выехал', comment: 'Мастер в пути, звонить за 30 минут', ago: 5 * 3600000 },
    { name: 'Алексей', phone: '+7 985 444-55-66', contact: 'MAX', addr: 'ул. Садовая', service: 'Кресло / стул × 2; загрязнение: лёгкое', price: 2400, high: 2880, status: 'Выполнено', comment: 'Оплатил по СБП', ago: 26 * 3600000 }
  ];
  return base.map((l, i) => ({
    id: now - l.ago - i,
    createdAt: now - l.ago,
    name: l.name,
    phone: l.phone,
    contact: l.contact,
    addr: l.addr,
    service: l.service,
    price: l.price,
    high: l.high,
    status: l.status,
    comment: l.comment,
    photos: [],
    videos: [],
    source: 'демо',
    delivery: []
  }));
}

/* ---------- Мессенджеры ---------- */
function waUrl(text) {
  const d = digits(settings.brand.wa).replace(/^8/, '7');
  if (!d) return '';
  return 'https://wa.me/' + d + (text ? '?text=' + encodeURIComponent(text) : '');
}

function tgUrl() {
  const raw = String(settings.brand.tg || '').trim();
  if (!raw) return '';
  if (/^https?:\/\//i.test(raw)) return raw;
  if (raw.indexOf('@') === 0) return 'https://t.me/' + raw.slice(1);
  const d = digits(raw);
  if (d.length >= 10) return 'tg://resolve?phone=' + d;
  return 'https://t.me/' + raw.replace(/^@/, '');
}

function maxUrl() {
  const raw = String(settings.brand.max || '').trim();
  if (!raw) return '';
  if (/^https?:\/\//i.test(raw)) return raw;
  if (raw.indexOf('@') === 0) return 'https://max.ru/' + raw.slice(1);
  return 'https://max.ru/' + raw;
}

function messengers() {
  const list = [];
  const tg = tgUrl();
  if (tg) list.push({ k: 'tg', n: 'Telegram', url: tg });
  const mx = maxUrl();
  if (mx) list.push({ k: 'max', n: 'MAX', url: mx });
  const wa = waUrl();
  if (wa) list.push({ k: 'wa', n: 'WhatsApp', url: wa });
  return list;
}

function telUrl(phone) {
  const d = digits(phone).replace(/^8/, '7');
  return d ? 'tel:+' + d : '';
}

/* ---------- Калькулятор ---------- */
function typeInfo(k) {
  return TYPES.find((t) => t.k === k) || TYPES[0];
}

function basePrice() {
  const t = typeInfo(state.type);
  const p = num(settings.prices[t.priceKey], 0);
  if (t.k === 'carpet') return p * Math.max(1, state.CL * state.CW);
  const coef = t.sizes ? num(settings.cfg.sizes[t.k][state.size], 1) : 1;
  return p * coef;
}

function stainAdd() {
  let sum = 0;
  state.stains.forEach((k) => { sum += num(settings.cfg.stains[k], 0); });
  return sum;
}

function calc() {
  const qty = Math.max(1, Math.min(20, Math.round(state.qty) || 1));
  const dirtCoef = num(settings.cfg.dirt[state.dirt], 1);
  const lo = basePrice() * qty * dirtCoef * (1 + stainAdd());
  const hard = state.stains.has('ink') || state.stains.has('mold') || state.dirt === 2;
  const hi = lo * (hard ? num(settings.cfg.hiHard, 1.35) : num(settings.cfg.hiNorm, 1.2));
  return { lo: Math.max(0, lo), hi: Math.max(0, hi), qty, hard };
}

function summary() {
  const t = typeInfo(state.type);
  let s = t.n;
  if (t.sizes) s += ', ' + (SIZE_LABELS[t.k][state.size] || '').toLowerCase();
  if (t.k === 'carpet') s += ' ' + state.CL + '×' + state.CW + ' м';
  else if (state.dims) s += ' (' + state.dims + ' см)';
  s += ' × ' + state.qty;
  s += '; загрязнение: ' + DIRT_LABELS[state.dirt].toLowerCase();
  const st = STAINS.filter((x) => state.stains.has(x.k)).map((x) => x.n);
  if (st.length) s += '; пятна: ' + st.join(', ');
  return s;
}

function renderTypeSeg() {
  $('#segType').innerHTML = TYPES.map((t) => `<button type="button" data-type="${t.k}" aria-pressed="${t.k === state.type}">${t.n}</button>`).join('');
}

function renderDirtSeg() {
  $('#segDirt').innerHTML = DIRT_LABELS.map((n, i) => `<button type="button" data-dirt="${i}" aria-pressed="${i === state.dirt}">${n}</button>`).join('');
}

function renderStains() {
  $('#stains').innerHTML = STAINS.map((s) => `<button type="button" data-stain="${s.k}" aria-pressed="${state.stains.has(s.k)}">${s.n}</button>`).join('');
}

function renderDyn() {
  const t = typeInfo(state.type);
  let html = '';
  if (t.sizes) {
    html += `<div class="field"><span class="lbl">Размер</span><div class="seg" id="segSize" role="group" aria-label="Размер">${SIZE_LABELS[t.k].map((label, i) => `<button type="button" data-size="${i}" aria-pressed="${i === state.size}">${label}</button>`).join('')}</div></div>`;
  }
  if (t.k === 'carpet') {
    html += `<div class="row2"><div class="field"><label class="lbl" for="cl">Длина, м</label><input class="input" id="cl" type="number" min=".5" step=".1" inputmode="decimal" value="${state.CL}"></div><div class="field"><label class="lbl" for="cw">Ширина, м</label><input class="input" id="cw" type="number" min=".5" step=".1" inputmode="decimal" value="${state.CW}"></div></div>`;
  } else {
    html += `<div class="field"><label class="lbl" for="dm">Размеры, см <span class="muted">— если знаете</span></label><input class="input" id="dm" type="text" placeholder="например, 200×90" value="${esc(state.dims)}"></div>`;
  }
  $('#dyn').innerHTML = html;
}

function renderPrep() {
  const t = typeInfo(state.type);
  const tips = [];
  tips.push({ sofa: 'Снимите подушки и съёмные чехлы, если они есть.', chair: 'Снимите подушки и съёмные чехлы.', mat: 'Снимите бельё и наматрасник.', carpet: 'Освободите ковёр от мебели и мелких предметов.' }[state.type]);
  tips.push('Освободите подход к мебели и уберите мелкие вещи. Рядом нужна розетка 220 В.');
  if (state.dirt === 2) tips.push('Сильное загрязнение может потребовать двух проходов — предупредим заранее.');
  state.stains.forEach((k) => {
    const s = STAINS.find((x) => x.k === k);
    if (s) tips.push(s.n + ': ' + s.hint);
  });
  tips.push('Высыхание обычно занимает 6–12 часов, проветрите комнату.');
  tips.push('Приложите фото пятен: так цена будет точной.');
  $('#prep').innerHTML = tips.map((t2) => `<li>${esc(t2)}</li>`).join('');
}

function updatePrice() {
  const r = calc();
  $('#price').textContent = 'от ' + money(r.lo);
  $('#range').innerHTML = 'Возможный диапазон: <b>' + money(r.lo) + ' – ' + money(r.hi) + '</b>';
  $('#csum').innerHTML = '<b>' + esc(summary()) + '</b>';
  renderPrep();
}

function renderCalc() {
  renderTypeSeg();
  renderDirtSeg();
  renderStains();
  renderDyn();
  updatePrice();
}

/* ---------- Сайт ---------- */
function applyBrand() {
  const b = settings.brand;
  document.documentElement.style.setProperty('--brand', b.color || DEFAULT_SETTINGS.brand.color);
  document.documentElement.style.setProperty('--brand-dark', shade(b.color || DEFAULT_SETTINGS.brand.color, -18));
  ['#brandName', '#brandName2', '#brandName3'].forEach((sel) => { const el = $(sel); if (el) el.textContent = b.name; });
  const logoHtml = b.logo ? `<img src="${esc(b.logo)}" alt="">` : `<span class="mk" aria-hidden="true"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 3c3.2 4.2 4.6 6.6 4.6 8.4a4.6 4.6 0 0 1-9.2 0C7.4 9.6 8.8 7.2 12 3z" fill="#d8f56e"/></svg></span>`;
  $$('.logo').forEach((a) => {
    const mark = a.querySelector('.mk, img');
    if (!mark) return;
    if (settings.brand.logo) {
      if (mark.tagName === 'IMG') { mark.src = settings.brand.logo; }
      else {
        const img = document.createElement('img');
        img.src = settings.brand.logo;
        img.alt = '';
        mark.replaceWith(img);
      }
    } else if (mark.tagName === 'IMG') {
      const span = document.createElement('span');
      span.className = 'mk';
      span.setAttribute('aria-hidden', 'true');
      span.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 3c3.2 4.2 4.6 6.6 4.6 8.4a4.6 4.6 0 0 1-9.2 0C7.4 9.6 8.8 7.2 12 3z" fill="#d8f56e"/></svg>';
      mark.replaceWith(span);
    }
  });

  const tel = telUrl(b.phone);
  const phoneEl = $('#hdrPhone');
  phoneEl.textContent = b.phone;
  phoneEl.href = tel;
  $('#contactPhone').textContent = b.phone;
  $('#contactPhone').href = tel;
  $('#mbarCall').href = tel;
  $('#contactCities').textContent = b.cities;
  $('#contactHours').textContent = b.hours;
  $('#footText').textContent = b.foot;
  $('#heroEyebrow').textContent = 'Выезд на дом · ' + b.cities;
  document.title = b.name + ' — химчистка мебели на дому';

  const heroImg = $('#heroImg');
  if (heroImg) heroImg.src = settings.photos.hero || IMG.hero;
  const bannerImg = $('.banner img');
  if (bannerImg) bannerImg.src = settings.photos.banner || IMG.banner;

  const ms = messengers();
  const heroMs = ms.filter((m) => m.k !== 'wa');
  const heroList = heroMs.length ? heroMs : ms;
  $('#heroMsgs').innerHTML = heroList.map((m) => `<a class="btn btn--ghost" href="${esc(m.url)}" target="_blank" rel="noopener">${m.n}</a>`).join('');
  const main = ms[0];
  const mb = $('#mbarMsg');
  mb.hidden = !main;
  if (main) {
    mb.href = main.url;
    mb.textContent = main.n;
    mb.className = 'msg ' + main.k;
  }
  $('#contactMsg').innerHTML = ms.map((m) => `<a class="c-msg ${m.k}" href="${esc(m.url)}" target="_blank" rel="noopener">${m.n}</a>`).join('');

  applyDemoVisibility();
}

function applyDemoVisibility() {
  const off = !!settings.security.pin;
  $$('[data-demo]').forEach((el) => { el.hidden = off; });
}

function shade(hex, percent) {
  const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(String(hex));
  if (!m) return hex;
  const amt = Math.round(2.55 * percent);
  const rgb = [1, 2, 3].map((i) => Math.max(0, Math.min(255, parseInt(m[i], 16) + amt)));
  return '#' + rgb.map((v) => v.toString(16).padStart(2, '0')).join('');
}

function applyTexts() {
  const t = settings.texts;
  $('#h1').innerHTML = esc(t.h1).replace(/\*(.+?)\*/g, '<mark>$1</mark>');
  $('#sub').textContent = t.sub;
  $('#perks').innerHTML = t.perks.map((p, i) => `
    <li class="perk">
      <span class="perk-ic" aria-hidden="true">${perkIcon(i)}</span>
      <div><b>${esc(p.t)}</b><span>${esc(p.d)}</span></div>
    </li>`).join('');
  $('#steps').innerHTML = t.steps.map((s, i) => `
    <li class="step${i === 2 ? ' step--dark' : ''}"><b>${esc(s.t)}</b><span>${esc(s.d)}</span></li>`).join('');
  $('#reviewsList').innerHTML = t.reviews.filter((r) => r.t.trim()).map((r) => `
    <article class="review">
      <div class="stars" aria-label="Оценка 5 из 5">★★★★★</div>
      <p>${esc(r.t)}</p>
      <footer>${esc(r.n)}</footer>
    </article>`).join('');
  $('#faqList').innerHTML = t.faq.map((f) => `
    <details>
      <summary>${esc(f.q)}</summary>
      <p>${esc(f.a)}</p>
    </details>`).join('');
}

function perkIcon(i) {
  const icons = [
    '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3c2.6 3.4 3.8 5.4 3.8 7a3.8 3.8 0 0 1-7.6 0C8.2 8.4 9.4 6.4 12 3z"/><path d="M6 15c1.6 2.2 3.6 3.3 6 3.3s4.4-1.1 6-3.3"/></svg>',
    '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8h13l5 4v5H3z"/><circle cx="7" cy="17" r="1.6"/><circle cx="17" cy="17" r="1.6"/><path d="M6 8V5h8v3"/></svg>',
    '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 11l8-7 8 7"/><path d="M6 10v9h12v-9"/><path d="M10 19v-5h4v5"/></svg>',
    '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>'
  ];
  return icons[i % icons.length];
}

function renderPrices() {
  const p = settings.prices;
  const rows = [
    { n: 'Диван', d: '2 места, стандартная ткань', v: p.sofa },
    { n: 'Кресло или стул', d: 'с подлокотниками и без', v: p.chair },
    { n: 'Матрас', d: 'двуспальный', v: p.mat },
    { n: 'Ковёр', d: 'за квадратный метр', v: p.carpetM2, unit: '/м²' }
  ];
  $('#priceTable').innerHTML = rows.map((r) => `
    <div class="pr-row"><div><b>${esc(r.n)}</b><br><small>${esc(r.d)}</small></div><span class="pr-dots"></span><span class="pr-val">от ${money(r.v)}${r.unit || ''}</span></div>`).join('');
  $('#heroPrice').textContent = 'от ' + money(p.sofa);
}

function galleryItems() {
  if (!Array.isArray(settings.photos.gallery) || !settings.photos.gallery.length) {
    settings.photos.gallery = clone(DEFAULT_GALLERY);
  }
  return settings.photos.gallery;
}

function renderWorks() {
  const items = galleryItems();
  $('#worksList').innerHTML = items.map((it) => {
    const before = resolveImg(it.before);
    const after = resolveImg(it.after);
    if (it.mode === 'pair' && after) {
      return `<article class="work">
        <div class="cmp" data-id="${esc(it.id)}">
          <img class="cmp-img" src="${esc(before)}" alt="До: ${esc(it.cap)}" loading="lazy" decoding="async">
          <div class="cmp-after"><img class="cmp-img" src="${esc(after)}" alt="После: ${esc(it.cap)}" loading="lazy" decoding="async"></div>
          <span class="cmp-tag">До</span>
          <span class="cmp-tag right">После</span>
          <span class="cmp-line"></span>
          <input type="range" min="0" max="100" value="50" step="1" aria-label="Сравнить до и после: ${esc(it.cap)}">
        </div>
        <div class="work-cap"><b>${esc(it.cap)}</b><span>Потяните, чтобы сравнить</span></div>
      </article>`;
    }
    return `<article class="work">
      <div class="ba single"><figure><img src="${esc(before)}" alt="${esc(it.cap)}" loading="lazy" decoding="async"></figure></div>
      <div class="work-cap"><b>${esc(it.cap)}</b></div>
    </article>`;
  }).join('') || '<p class="hint">Скоро здесь появятся наши работы.</p>';
}

function applyAll() {
  applyBrand();
  applyTexts();
  renderPrices();
  renderWorks();
  updatePrice();
  renderBrandPreview();
  renderCalcExample();
  $$('[data-set]').forEach((el) => { if (document.activeElement !== el) el.value = getPath(settings, el.dataset.set); });
}

function getPath(obj, path) {
  return path.split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj);
}

/* ---------- Медиа формы ---------- */
function compressImage(file, maxSide = 1000, quality = 0.72) {
  return new Promise((resolve) => {
    if (!file || !/^image\//.test(file.type)) return resolve('');
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      try {
        const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        URL.revokeObjectURL(url);
        resolve(canvas.toDataURL('image/jpeg', quality));
      } catch (e) {
        URL.revokeObjectURL(url);
        resolve('');
      }
    };
    img.onerror = () => { URL.revokeObjectURL(url); resolve(''); };
    img.src = url;
  });
}

function videoPoster(file) {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const v = document.createElement('video');
    v.muted = true;
    v.playsInline = true;
    v.preload = 'metadata';
    v.src = url;
    let done = false;
    const finish = (val) => {
      if (done) return;
      done = true;
      URL.revokeObjectURL(url);
      resolve(val);
    };
    v.onloadeddata = () => { try { v.currentTime = Math.min(0.5, (v.duration || 1) / 2); } catch (e) {} };
    v.onseeked = () => {
      try {
        const scale = Math.min(1, 480 / Math.max(v.videoWidth || 1, v.videoHeight || 1));
        const c = document.createElement('canvas');
        c.width = Math.round((v.videoWidth || 320) * scale);
        c.height = Math.round((v.videoHeight || 180) * scale);
        c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
        finish(c.toDataURL('image/jpeg', 0.7));
      } catch (e) { finish(''); }
    };
    v.onerror = () => finish('');
    setTimeout(() => finish(''), 4000);
  });
}

function renderMediaChips() {
  $('#chips').innerHTML = media.map((m, i) => `
    <span class="chip"><img src="${esc(m.kind === 'video' ? m.poster : m.src)}" alt="">${m.kind === 'video' ? '<i class="pl">▶</i>' : ''}<button type="button" data-rm="${i}" aria-label="Убрать файл">×</button></span>`).join('');
  $('#chipsCount').textContent = media.length ? `Добавлено: ${media.length} из 6` : '';
}

async function takeFiles(fileList) {
  const files = Array.from(fileList || []);
  for (const f of files) {
    if (media.length >= 6) { toast('Можно добавить до 6 файлов'); break; }
    if (/^video\//.test(f.type)) {
      const poster = await videoPoster(f);
      media.push({ kind: 'video', name: f.name, poster: poster || '' });
    } else if (!f.type || /^image\//.test(f.type)) {
      const src = await compressImage(f, 1000, 0.72);
      if (src) media.push({ kind: 'photo', src: src, name: f.name });
      else toast('Не удалось прочитать фото: ' + f.name);
    }
  }
  renderMediaChips();
}

/* ---------- Форма ---------- */
function maskPhone(value) {
  let d = digits(value);
  if (!d) return '';
  if (d.charAt(0) === '8') d = '7' + d.slice(1);
  if (d.charAt(0) === '9') d = '7' + d;
  if (d.charAt(0) !== '7') d = '7' + d;
  d = d.slice(0, 11);
  let out = '+7';
  if (d.length > 1) out += ' (' + d.slice(1, 4);
  if (d.length >= 5) out += ') ' + d.slice(4, 7);
  if (d.length >= 8) out += '-' + d.slice(7, 9);
  if (d.length >= 10) out += '-' + d.slice(9, 11);
  return out;
}

function fieldError(id, msg) {
  const err = $('#err-' + id);
  const input = $('#' + id);
  if (err) { err.textContent = msg || ''; err.classList.toggle('on', !!msg); }
  if (input) input.setAttribute('aria-invalid', msg ? 'true' : 'false');
}

function clearErrors() {
  ['name', 'phone', 'addr', 'agree'].forEach((k) => fieldError(k, ''));
}

function validateForm() {
  clearErrors();
  const errors = [];
  const name = $('#name').value.trim();
  const phone = $('#phone').value;
  const addr = $('#addr').value.trim();
  if (name.length < 2) { fieldError('name', 'Напишите имя — как к вам обращаться'); errors.push('name'); }
  if (digits(phone).length !== 11) { fieldError('phone', 'Введите телефон полностью: +7 (___) ___-__-__'); errors.push('phone'); }
  if (addr.length < 3) { fieldError('addr', 'Укажите район или адрес — чтобы понять, приедем ли'); errors.push('addr'); }
  if (!$('#agree').checked) { fieldError('agree', 'Нужно согласие на обработку данных'); errors.push('agree'); }
  if (errors.length) {
    const first = $('#' + errors[0]);
    if (first) { first.focus(); first.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
    return false;
  }
  return true;
}

function newLeadFromForm() {
  const r = calc();
  return {
    id: Date.now(),
    createdAt: Date.now(),
    name: $('#name').value.trim(),
    phone: $('#phone').value,
    contact: $('#contact').value,
    addr: $('#addr').value.trim(),
    service: summary(),
    price: Math.round(r.lo),
    high: Math.round(r.hi),
    status: 'Новая',
    comment: $('#cm').value.trim(),
    photos: media.filter((m) => m.kind === 'photo').map((m) => m.src),
    videos: media.filter((m) => m.kind === 'video').map((m) => ({ name: m.name, poster: m.poster })),
    source: 'сайт',
    delivery: []
  };
}

function leadMessage(lead) {
  return 'Новая заявка с сайта\n' +
    'Имя: ' + lead.name + '\n' +
    'Телефон: ' + lead.phone + '\n' +
    'Связь: ' + lead.contact + '\n' +
    'Адрес: ' + lead.addr + '\n' +
    'Услуга: ' + lead.service + '\n' +
    'Цена: ' + money(lead.price) + (lead.high ? ' – ' + money(lead.high) : '') + '\n' +
    (lead.comment ? 'Комментарий: ' + lead.comment + '\n' : '');
}

async function fetchTimeout(url, options, ms) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms || 7000);
  try {
    return await fetch(url, Object.assign({}, options, { signal: ctrl.signal }));
  } finally {
    clearTimeout(t);
  }
}

async function notifyLead(lead) {
  const result = [];
  const tg = NC_DELIVERY.telegram;
  if (tg.token && tg.chatId) {
    try {
      const res = await fetchTimeout('https://api.telegram.org/bot' + tg.token + '/sendMessage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: tg.chatId, text: leadMessage(lead), disable_web_page_preview: true })
      }, 7000);
      result.push({ channel: 'telegram', ok: res.ok });
    } catch (e) { result.push({ channel: 'telegram', ok: false }); }
  }
  const em = NC_DELIVERY.email;
  if (em.endpoint) {
    try {
      const res = await fetchTimeout(em.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          _subject: 'Заявка NovaClean: ' + lead.name,
          name: lead.name,
          phone: lead.phone,
          contact: lead.contact,
          address: lead.addr,
          service: lead.service,
          price: lead.price + ' – ' + lead.high,
          comment: lead.comment
        })
      }, 7000);
      result.push({ channel: 'email', ok: res.ok });
    } catch (e) { result.push({ channel: 'email', ok: false }); }
  }
  return result;
}

function showSuccess(lead) {
  const r = calc();
  $('#successSum').innerHTML = esc(lead.service) + '<b>' + money(lead.price) + (lead.high ? ' – ' + money(lead.high) : '') + '</b>';
  const ms = messengers();
  const main = ms.find((m) => m.k === 'tg') || ms[0];
  const link = $('#successMsg');
  if (main) {
    link.href = main.url;
    link.textContent = 'Написать в ' + main.n;
    link.hidden = false;
  } else {
    link.hidden = true;
  }
  $('#form').hidden = true;
  $('#success').hidden = false;
  $('#success').scrollIntoView({ block: 'center', behavior: 'smooth' });
}

function resetForm() {
  $('#form').reset();
  $('#phone').value = '';
  media = [];
  renderMediaChips();
  clearErrors();
}

function hideSuccess() {
  $('#success').hidden = true;
  $('#form').hidden = false;
  $('#name').focus();
}

/* ---------- Кабинет: заявки ---------- */
function filteredLeads() {
  const q = searchQuery.trim().toLowerCase();
  return leads
    .filter((l) => !statusFilter || l.status === statusFilter)
    .filter((l) => !q || (l.name + ' ' + l.phone + ' ' + l.addr + ' ' + l.service + ' ' + (l.comment || '')).toLowerCase().includes(q))
    .sort((a, b) => (Number(b.createdAt) || 0) - (Number(a.createdAt) || 0));
}

function renderStats() {
  const n = (s) => leads.filter((l) => l.status === s).length;
  const active = leads.filter((l) => l.status !== 'Отказ');
  const sum = active.reduce((a, l) => a + (Number(l.price) || 0), 0);
  $('#stats').innerHTML = `
    <div class="stat"><b>${n('Новая')}</b><span>новых заявок</span></div>
    <div class="stat"><b>${n('В обработке') + n('Выехал')}</b><span>в работе</span></div>
    <div class="stat"><b>${n('Выполнено')}</b><span>выполнено</span></div>
    <div class="stat stat--accent"><b>${money(sum)}</b><span>сумма активных заявок</span></div>`;
  const badge = $('#newBadge');
  const cnt = n('Новая');
  badge.textContent = cnt;
  badge.hidden = !cnt;
}

function renderLeads() {
  renderStats();
  if (!$('#leadsView')) return;
  if (adminView === 'board') renderBoard();
  else renderList();
}

function renderList() {
  const items = filteredLeads();
  if (!items.length) {
    $('#leadsView').innerHTML = `<div class="empty"><b>${leads.length ? 'Ничего не найдено' : 'Заявок пока нет'}</b><p>${leads.length ? 'Измените поиск или фильтр.' : 'Заявки с сайта появятся здесь автоматически. Можно добавить вручную кнопкой «+ Заявка».'}</p></div>`;
    return;
  }
  const rows = items.map((l) => {
    const tel = telUrl(l.phone);
    return `<tr data-id="${l.id}">
      <td class="lclient-td" data-l="">
        <div class="lclient">
          <span class="av ${l.status === 'Новая' ? 'av--new' : ''}">${esc((l.name.trim().charAt(0) || '?').toUpperCase())}</span>
          <div><b>${esc(l.name)}</b><span>${timeAgo(l.createdAt)} · ${esc(l.contact || 'Позвонить')}</span></div>
        </div>
      </td>
      <td data-l="Телефон"><a class="lphone" href="${esc(tel)}" onclick="event.stopPropagation()">${esc(l.phone)}</a></td>
      <td data-l="Услуга" class="lsvc">${esc(l.service)}${l.comment ? '<small>' + esc(l.comment) + '</small>' : ''}</td>
      <td data-l="Сумма" class="lsum">${money(l.price)}${l.high ? '<small>до ' + money(l.high) + '</small>' : ''}</td>
      <td data-l="Статус"><span class="status ${STATUS_CLASS[l.status] || 'st-new'}">${esc(l.status)}</span></td>
      <td class="actions-td" data-l="">
        <div class="row-actions">
          ${l.photos && l.photos.length ? `<button class="ia" type="button" data-photos="${l.id}" title="Фото" aria-label="Фото">${cameraIcon()}</button>` : ''}
          <button class="ia" type="button" data-edit="${l.id}" title="Изменить" aria-label="Изменить">${pencilIcon()}</button>
        </div>
      </td>
    </tr>`;
  }).join('');
  $('#leadsView').innerHTML = `<div class="ltable-wrap"><table class="ltable">
    <thead><tr><th>Клиент</th><th>Телефон</th><th>Услуга</th><th>Сумма</th><th>Статус</th><th></th></tr></thead>
    <tbody>${rows}</tbody>
  </table></div>`;
}

function cameraIcon() {
  return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h3l2-2h6l2 2h3v11H4z"/><circle cx="12" cy="13" r="3"/></svg>';
}

function pencilIcon() {
  return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h4L20 8l-4-4L4 16z"/><path d="M14 6l4 4"/></svg>';
}

function renderBoard() {
  const items = filteredLeads();
  $('#leadsView').innerHTML = `<div class="kanban">${STATUSES.map((st) => {
    const group = items.filter((l) => l.status === st);
    return `<div class="kcol" data-status="${st}">
      <h3><span>${st}</span><span class="n">${group.length}</span></h3>
      ${group.map((l) => `
        <div class="kcard" draggable="true" data-id="${l.id}">
          <div class="kcard-top">
            <span class="av ${l.status === 'Новая' ? 'av--new' : ''}" style="width:26px;height:26px;font-size:11px">${esc((l.name.trim().charAt(0) || '?').toUpperCase())}</span>
            <b>${esc(l.name)}</b>
            <span class="price-tag">${money(l.price)}</span>
          </div>
          <div class="meta">${timeAgo(l.createdAt)} · ${esc(l.contact || 'Позвонить')}</div>
          <div class="svc">${esc(l.service)}</div>
          <div class="acts">
            <button class="ia" type="button" data-edit="${l.id}">Открыть</button>
          </div>
        </div>`).join('') || '<div class="empty" style="padding:18px;font-size:12px">Пусто</div>'}
    </div>`;
  }).join('')}</div>`;
}

function openLead(id) {
  const isNew = !id;
  const lead = isNew
    ? { id: Date.now(), createdAt: Date.now(), name: '', phone: '', contact: 'Позвонить', addr: '', service: '', price: 0, high: 0, status: 'Новая', comment: '', photos: [], videos: [], source: 'вручную', delivery: [] }
    : leads.find((l) => String(l.id) === String(id));
  if (!lead) return;
  let photos = (lead.photos || []).slice();
  const body = `
    <form id="leadForm">
      <div class="row2">
        <div class="field"><label class="lbl" for="e_name">Имя</label><input class="input" id="e_name" value="${esc(lead.name)}" autofocus></div>
        <div class="field"><label class="lbl" for="e_phone">Телефон</label><input class="input" id="e_phone" type="tel" value="${esc(lead.phone)}"></div>
      </div>
      <div class="row2">
        <div class="field"><label class="lbl" for="e_contact">Связь</label><select class="select" id="e_contact">${['Позвонить', 'WhatsApp', 'Telegram', 'MAX'].map((c) => `<option${c === lead.contact ? ' selected' : ''}>${c}</option>`).join('')}</select></div>
        <div class="field"><label class="lbl" for="e_status">Статус</label><select class="select" id="e_status">${STATUSES.map((s) => `<option${s === lead.status ? ' selected' : ''}>${s}</option>`).join('')}</select></div>
      </div>
      <div class="field"><label class="lbl" for="e_addr">Адрес</label><input class="input" id="e_addr" value="${esc(lead.addr)}"></div>
      <div class="field"><label class="lbl" for="e_service">Услуга и параметры</label><textarea class="ta" id="e_service" rows="2">${esc(lead.service)}</textarea></div>
      <div class="row2">
        <div class="field"><label class="lbl" for="e_price">Цена от, ₽</label><input class="input" id="e_price" type="number" step="1" value="${Math.round(lead.price) || 0}"></div>
        <div class="field"><label class="lbl" for="e_high">Цена до, ₽</label><input class="input" id="e_high" type="number" step="1" value="${Math.round(lead.high) || 0}"></div>
      </div>
      <div class="field"><label class="lbl" for="e_comment">Комментарий</label><textarea class="ta" id="e_comment" rows="2">${esc(lead.comment || '')}</textarea></div>
      <div class="field">
        <span class="lbl">Фото (${photos.length})</span>
        <div class="chips" id="e_photos" style="justify-content:flex-start"></div>
        <label class="ab" style="display:inline-flex;margin-top:8px;padding:8px 12px;border-radius:8px;background:var(--panel);cursor:pointer">+ Добавить фото<input type="file" id="e_file" accept="image/*" multiple hidden></label>
      </div>
      <p class="hint" style="margin-top:8px">Создано: ${dateFull(lead.createdAt)} · источник: ${esc(lead.source || '—')}</p>
    </form>`;
  const foot = `<button class="btn" type="submit" form="leadForm">Сохранить</button>
    <button class="btn btn--ghost" type="button" data-close>Отмена</button>
    ${isNew ? '' : `<button class="btn danger" type="button" id="delLead" style="flex:0 0 auto">Удалить</button>`}`;
  const modal = Modal.open(
    `<div class="modal-head"><div><h3>${isNew ? 'Новая заявка' : 'Заявка: ' + esc(lead.name)}</h3><p>${isNew ? 'Заполните данные клиента' : timeAgo(lead.createdAt)}</p></div><button class="x" type="button" data-close aria-label="Закрыть">✕</button></div>
     <div class="modal-body">${body}</div>
     <div class="modal-foot">${foot}</div>`,
    { label: 'Заявка' }
  );

  const drawPhotos = () => {
    const wrap = $('#e_photos');
    wrap.innerHTML = photos.map((p, i) => `<span class="chip" style="background:var(--panel)"><img src="${esc(p)}" alt="Фото ${i + 1}"><button type="button" data-rmphoto="${i}" aria-label="Удалить фото">×</button></span>`).join('') || '<span class="hint">Фото нет</span>';
  };
  drawPhotos();

  $('#e_photos').onclick = (e) => {
    const b = e.target.closest('[data-rmphoto]');
    if (b) { photos.splice(Number(b.dataset.rmphoto), 1); drawPhotos(); }
  };
  $('#e_file').onchange = async (e) => {
    for (const f of Array.from(e.target.files).slice(0, 6)) {
      const src = await compressImage(f, 1100, 0.72);
      if (src) photos.push(src);
    }
    e.target.value = '';
    drawPhotos();
  };

  $('#leadForm').onsubmit = async (e) => {
    e.preventDefault();
    const name = $('#e_name').value.trim();
    if (!name) { $('#e_name').focus(); toast('Укажите имя'); return; }
    Object.assign(lead, {
      name,
      phone: $('#e_phone').value.trim(),
      contact: $('#e_contact').value,
      addr: $('#e_addr').value.trim(),
      service: $('#e_service').value.trim(),
      price: num($('#e_price').value, 0),
      high: num($('#e_high').value, 0),
      status: $('#e_status').value,
      comment: $('#e_comment').value.trim(),
      photos
    });
    try {
      await store.putLead(lead);
      if (isNew) leads.unshift(lead);
      renderLeads();
      modal.close();
      toast(isNew ? 'Заявка добавлена' : 'Сохранено');
    } catch (err) { toast('Не удалось сохранить: ' + err.message); }
  };

  const del = $('#delLead');
  if (del) del.onclick = async () => {
    if (!del.dataset.sure) { del.dataset.sure = '1'; del.textContent = 'Точно удалить?'; return; }
    const removed = lead;
    leads = leads.filter((l) => l.id !== lead.id);
    await store.delLead(lead.id);
    renderLeads();
    modal.close();
    toast('Заявка удалена', { label: 'Отменить', run: async () => { leads.unshift(removed); await store.putLead(removed); renderLeads(); } });
  };
}

/* ---------- Кабинет: фото ---------- */
function renderPhotos() {
  $('#pvHero').src = settings.photos.hero || IMG.hero;
  $('#pvBanner').src = settings.photos.banner || IMG.banner;
  const items = galleryItems();
  $('#galleryList').innerHTML = items.map((it, i) => `
    <div class="pli" data-i="${i}">
      <div class="thumbs"><img src="${esc(resolveImg(it.before))}" alt="">${it.after ? `<img src="${esc(resolveImg(it.after))}" alt="">` : ''}</div>
      <input type="text" value="${esc(it.cap)}" data-cap="${i}" aria-label="Подпись">
      <div class="ib">
        <button class="ia" type="button" data-move="-1" ${i === 0 ? 'disabled' : ''} aria-label="Выше">↑</button>
        <button class="ia" type="button" data-move="1" ${i === items.length - 1 ? 'disabled' : ''} aria-label="Ниже">↓</button>
        <button class="ia" type="button" data-delwork="${i}" aria-label="Удалить">✕</button>
      </div>
    </div>`).join('') || '<div class="hint">Пока нет работ.</div>';
}

async function applyVideo() {
  let blob = null;
  try { blob = await store.getVideo(); } catch (e) {}
  if (videoUrl) { URL.revokeObjectURL(videoUrl); videoUrl = null; }
  const site = $('#siteVideo');
  const pv = $('#pvVideo');
  const section = $('#vsec');
  if (blob) {
    videoUrl = URL.createObjectURL(blob);
    site.src = videoUrl;
    pv.src = videoUrl;
    section.hidden = false;
    pv.hidden = false;
  } else {
    site.removeAttribute('src');
    pv.removeAttribute('src');
    section.hidden = true;
    pv.hidden = true;
  }
}

/* ---------- Кабинет: настройки ---------- */
function bindSettingsForms() {
  $$('[data-set]').forEach((el) => {
    const path = el.dataset.set;
    el.value = getPath(settings, path) == null ? '' : getPath(settings, path);
    if (el.type === 'number') el.value = num(getPath(settings, path), 0);
  });
  $('#t_h1').value = settings.texts.h1;
  $('#t_sub').value = settings.texts.sub;
  renderEditors();
  $('#b_pin').value = '';
}

function renderEditors() {
  const t = settings.texts;
  $('#perksEdit').innerHTML = t.perks.map((p, i) => `
    <div class="sitem">
      <div class="sgrid">
        <div class="srow"><label>Заголовок ${i + 1}</label><input class="input" data-edit="texts.perks.${i}.t" value="${esc(p.t)}"></div>
        <div class="srow"><label>Описание ${i + 1}</label><input class="input" data-edit="texts.perks.${i}.d" value="${esc(p.d)}"></div>
      </div>
    </div>`).join('');
  $('#stepsEdit').innerHTML = t.steps.map((s, i) => `
    <div class="sitem">
      <div class="sgrid">
        <div class="srow"><label>Шаг ${i + 1}</label><input class="input" data-edit="texts.steps.${i}.t" value="${esc(s.t)}"></div>
        <div class="srow"><label>Что происходит</label><input class="input" data-edit="texts.steps.${i}.d" value="${esc(s.d)}"></div>
      </div>
    </div>`).join('');
  $('#reviewsEdit').innerHTML = t.reviews.map((r, i) => `
    <div class="sitem">
      <div class="sgrid">
        <div class="srow"><label>Отзыв ${i + 1}: имя</label><input class="input" data-edit="texts.reviews.${i}.n" value="${esc(r.n)}"></div>
        <div class="srow full"><label>Текст отзыва</label><textarea class="ta" rows="2" data-edit="texts.reviews.${i}.t">${esc(r.t)}</textarea></div>
      </div>
      <button class="btn btn--sm btn--ghost sdel" type="button" data-del="reviews.${i}">Удалить отзыв</button>
    </div>`).join('');
  $('#faqEdit').innerHTML = t.faq.map((f, i) => `
    <div class="sitem">
      <div class="sgrid">
        <div class="srow full"><label>Вопрос ${i + 1}</label><input class="input" data-edit="texts.faq.${i}.q" value="${esc(f.q)}"></div>
        <div class="srow full"><label>Ответ</label><textarea class="ta" rows="2" data-edit="texts.faq.${i}.a">${esc(f.a)}</textarea></div>
      </div>
      <button class="btn btn--sm btn--ghost sdel" type="button" data-del="faq.${i}">Удалить вопрос</button>
    </div>`).join('');
  renderStainRates();
}

function renderStainRates() {
  $('#stainRates').innerHTML = STAINS.map((s) => `
    <div class="srow"><label for="k_t_${s.k}">${esc(s.n)}</label><input class="input" id="k_t_${s.k}" type="number" min="0" step="0.05" data-set="cfg.stains.${s.k}"></div>`).join('');
  $$('#stainRates [data-set]').forEach((el) => { el.value = num(getPath(settings, el.dataset.set), 0); });
}

function renderBrandPreview() {
  const b = settings.brand;
  $('#brandPreview').innerHTML = `
    <div class="pv-top">${b.logo ? `<img src="${esc(b.logo)}" alt="" style="height:24px;border-radius:6px">` : '<span class="mk" style="width:24px;height:24px;border-radius:7px;background:var(--brand);display:inline-block"></span>'}<b>${esc(b.name)}</b><span>${esc(b.phone)}</span></div>
    <div class="pv-body" style="background:var(--deep)">
      <h4>Химчистка мебели на дому</h4>
      <span class="b" style="background:var(--lime)">Рассчитать стоимость</span>
      <div class="pv-rows"><i></i><i></i><i></i></div>
    </div>`;
}

function renderCalcExample() {
  const p = settings.prices;
  const base = num(p.sofa, 0) * num(settings.cfg.sizes.sofa[1], 1.3);
  const lo = base * num(settings.cfg.dirt[1], 1.25) * (1 + num(settings.cfg.stains.coffee, 0.1));
  const hi = lo * num(settings.cfg.hiNorm, 1.2);
  const text = `Диван на 3 места, среднее загрязнение, кофе: ${money(lo)} – ${money(hi)}.`;
  if ($('#calcExample')) $('#calcExample').textContent = text;
  if ($('#calcExample2')) $('#calcExample2').textContent = text;
}

/* ---------- Кабинет: вкладки и роутинг ---------- */
function setTab(name) {
  adminTab = name;
  $$('.atab').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.tab === name)));
  $$('.tabp').forEach((p) => { p.hidden = p.id !== 'p-' + name; });
  if (name === 'leads') renderLeads();
  if (name === 'photos') { renderPhotos(); applyVideo(); }
  if (name === 'prices') { bindSettingsForms(); renderCalcExample(); }
  if (name === 'brand') { bindSettingsForms(); renderBrandPreview(); }
  if (name === 'texts') renderEditors();
  if (name === 'data') { renderStorageInfo(); renderNotifyStatus(); }
  if (location.hash !== '#admin/' + name) {
    try { history.replaceState(null, '', '#admin/' + name); } catch (e) {}
  }
}

function openAdmin(tab) {
  document.body.classList.add('admin-mode');
  $('#admin').hidden = false;
  $('#site').hidden = true;
  setTab(tab || 'leads');
  window.scrollTo(0, 0);
}

function openSite(scrollTop) {
  document.body.classList.remove('admin-mode');
  $('#admin').hidden = true;
  $('#site').hidden = false;
  if (location.hash.startsWith('#admin')) {
    try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {}
  }
  if (scrollTop) window.scrollTo(0, 0);
}

async function route() {
  const h = location.hash;
  if (h.indexOf('#admin') === 0) {
    const tab = h.split('/')[1] || 'leads';
    if (settings.security.pin && !authorized) { showPinGate(tab); return; }
    openAdmin(tab);
  } else {
    openSite(false);
  }
}

function showPinGate(tab) {
  openSite(false);
  const m = Modal.open(
    `<div class="modal-head"><div><h3>Вход в кабинет</h3><p>Введите код из 4 цифр</p></div><button class="x" type="button" data-close aria-label="Закрыть">✕</button></div>
     <div class="modal-body">
       <form id="pinForm">
         <div class="field"><label class="lbl" for="pinInput">Код</label><input class="input" id="pinInput" type="password" inputmode="numeric" maxlength="4" autocomplete="off" autofocus></div>
         <button class="btn btn--block" type="submit">Войти</button>
       </form>
     </div>`,
    { label: 'Вход в кабинет' }
  );
  $('#pinForm').onsubmit = async (e) => {
    e.preventDefault();
    const hash = await hashPin($('#pinInput').value.trim());
    if (hash === settings.security.pin) {
      authorized = true;
      m.close();
      openAdmin(tab);
    } else {
      toast('Неверный код');
      $('#pinInput').select();
    }
  };
}

async function hashPin(pin) {
  const text = 'novaclean:' + pin;
  if (window.crypto && crypto.subtle) {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
  }
  let h = 0;
  for (let i = 0; i < text.length; i++) h = (h * 31 + text.charCodeAt(i)) | 0;
  return 'weak:' + h;
}

/* ---------- Модалки / тосты ---------- */
const Modal = (() => {
  let lastFocus = null;
  let open = false;
  const root = () => document.getElementById('modalRoot');
  function close() {
    const r = root();
    r.innerHTML = '';
    document.removeEventListener('keydown', onKey);
    document.body.style.overflow = '';
    open = false;
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  function onKey(e) { if (e.key === 'Escape' && open) close(); }
  function api(html, opts) {
    opts = opts || {};
    lastFocus = document.activeElement;
    const r = root();
    r.innerHTML = `<div class="modal" data-backdrop><div class="modal-card${opts.wide ? ' wide' : ''}" role="dialog" aria-modal="true" aria-label="${esc(opts.label || 'Окно')}">${html}</div></div>`;
    const back = r.querySelector('[data-backdrop]');
    back.addEventListener('mousedown', (e) => { if (e.target === back) close(); });
    r.querySelectorAll('[data-close]').forEach((b) => { b.onclick = close; });
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    open = true;
    const focusEl = r.querySelector('[autofocus]') || r.querySelector('input,select,textarea,button');
    if (focusEl) setTimeout(() => { try { focusEl.focus(); } catch (e) {} }, 40);
    return { close };
  }
  return { open: api, close };
})();

let toastTimer = null;
function toast(message, action) {
  const el = $('#toast');
  el.innerHTML = '<span>' + esc(message) + '</span>' + (action ? '<button type="button" id="toastAction">' + esc(action.label) + '</button>' : '');
  el.classList.add('on');
  clearTimeout(toastTimer);
  const hide = () => { el.classList.remove('on'); el.innerHTML = ''; };
  toastTimer = setTimeout(hide, action ? 6000 : 3200);
  if (action) {
    $('#toastAction').onclick = () => { hide(); action.run(); };
  }
}

function openPolicy() {
  Modal.open(
    `<div class="modal-head"><div><h3>Политика обработки персональных данных</h3><p>Как мы обрабатываем и храним ваши данные</p></div><button class="x" type="button" data-close aria-label="Закрыть">✕</button></div>
     <div class="modal-body policy">
      <p>Настоящая Политика описывает, как ${esc(settings.brand.name)} обрабатывает персональные данные, которые вы оставляете на сайте.</p>
      <h4>1. Какие данные мы собираем</h4>
      <p>Имя, телефон, адрес или район выезда, комментарий и фотографии мебели, которые вы прикладываете добровольно. Мы не запрашиваем паспортные данные и данные банковских карт.</p>
      <h4>2. Зачем</h4>
      <ul><li>связаться с вами по заявке и уточнить детали;</li><li>рассчитать стоимость и согласовать время выезда;</li><li>напомнить о визите мастера.</li></ul>
      <h4>3. Правовые основания</h4>
      <p>Ваше согласие, выраженное отметкой в форме. Согласие можно отозвать, написав нам на контакты из подвала сайта.</p>
      <h4>4. Кому передаём</h4>
      <p>Никому, кроме мастера, который выполняет вашу заявку. Мы не продаём и не передаём данные рекламным сервисам.</p>
      <h4>5. Сколько храним</h4>
      <p>До 12 месяцев с момента последней заявки, если вы не попросите удалить данные раньше.</p>
      <h4>6. Ваши права</h4>
      <p>Вы можете запросить копию, исправление или удаление своих данных, отозвать согласие. Для этого свяжитесь с нами по телефону ${esc(settings.brand.phone)}.</p>
      <h4>7. Изменения политики</h4>
      <p>Мы можем обновлять эту Политику. Актуальная версия всегда доступна на этой странице.</p>
     </div>
     <div class="modal-foot"><button class="btn" type="button" data-close>Понятно</button></div>`,
    { label: 'Политика конфиденциальности', wide: true }
  );
}

/* ---------- Данные ---------- */
async function downloadBackup() {
  const payload = {
    app: 'novaclean',
    version: 5,
    exportedAt: new Date().toISOString(),
    settings: settingsWithoutPhotos(),
    photos: settings.photos,
    leads
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'novaclean-backup-' + new Date().toISOString().slice(0, 10) + '.json';
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  toast('Резервная копия скачана');
}

function toCsv(rows) {
  return rows.map((r) => r.map((v) => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"').join(';')).join('\r\n');
}

function exportCsv() {
  const rows = [['Дата', 'Имя', 'Телефон', 'Связь', 'Адрес', 'Услуга', 'Цена от', 'Цена до', 'Статус', 'Комментарий', 'Фото']];
  filteredLeads().forEach((l) => {
    rows.push([
      new Date(Number(l.createdAt) || Date.now()).toLocaleString('ru-RU'),
      l.name, l.phone, l.contact || '', l.addr, l.service, l.price, l.high, l.status, l.comment || '', (l.photos || []).length
    ]);
  });
  const blob = new Blob(['\ufeff' + toCsv(rows)], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'novaclean-leads-' + new Date().toISOString().slice(0, 10) + '.csv';
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  toast('CSV скачан');
}

async function importBackup(file) {
  const text = await file.text();
  let data;
  try { data = JSON.parse(text); } catch (e) { toast('Файл повреждён'); return; }
  if (!data || data.app !== 'novaclean') { toast('Это не резервная копия NovaClean'); return; }
  if (!confirm('Заменить текущие данные данными из файла?')) return;
  settings = deepMerge(clone(DEFAULT_SETTINGS), data.settings || {});
  settings.photos = deepMerge(clone(DEFAULT_SETTINGS.photos), data.photos || {});
  leads = (Array.isArray(data.leads) ? data.leads : []).map((l) => Object.assign({
    id: Date.now(), createdAt: Date.now(), photos: [], videos: [], delivery: []
  }, l));
  await persistSettings();
  await persistPhotos();
  await store.clearLeads();
  for (const l of leads) await store.putLead(l);
  bindSettingsForms();
  applyAll();
  renderLeads();
  renderPhotos();
  toast('Данные восстановлены');
}

async function persistSettings() {
  setSaveState('saving');
  try {
    await store.putSettings(settingsWithoutPhotos());
    setSaveState('saved');
  } catch (e) {
    setSaveState('error');
    toast('Не удалось сохранить настройки');
  }
}

async function persistPhotos() {
  try { await store.putPhotos(settings.photos); }
  catch (e) { toast('Не удалось сохранить фото'); }
}

let photoTimer = null;
function schedulePhotosSave() {
  clearTimeout(photoTimer);
  photoTimer = setTimeout(persistPhotos, 500);
}

let stateTimer = null;
function setSaveState(kind) {
  const el = $('#saveState');
  if (!el) return;
  clearTimeout(stateTimer);
  if (kind === 'saving') el.textContent = 'Сохраняем…';
  else if (kind === 'error') el.textContent = 'Ошибка сохранения';
  else {
    el.textContent = 'Сохранено';
    stateTimer = setTimeout(() => { el.textContent = 'Все изменения сохраняются'; }, 2200);
  }
}

function scheduleSave() {
  clearTimeout(saveTimer);
  setSaveState('saving');
  saveTimer = setTimeout(() => { persistSettings(); }, 600);
}

async function renderStorageInfo() {
  const el = $('#storageInfo');
  if (!el) return;
  let text = 'Хранилище: ' + (store.mode === 'idb' ? 'IndexedDB' : 'localStorage') + '. Заявок: ' + leads.length + '.';
  if (navigator.storage && navigator.storage.estimate) {
    try {
      const est = await navigator.storage.estimate();
      if (est.usage) text += ' Занято примерно ' + (est.usage / 1048576).toFixed(1) + ' МБ.';
    } catch (e) {}
  }
  el.textContent = text;
}

function renderNotifyStatus() {
  const el = $('#notifyStatus');
  if (!el) return;
  const parts = [];
  if (NC_DELIVERY.telegram.token && NC_DELIVERY.telegram.chatId) parts.push('Telegram');
  if (NC_DELIVERY.email.endpoint) parts.push('e-mail');
  el.textContent = parts.length
    ? 'Подключено: ' + parts.join(', ') + '. Заявки будут отправляться автоматически.'
    : 'Уведомления не подключены. Откройте файл и заполните NC_DELIVERY в начале скрипта — заявки будут приходить в Telegram и на почту.';
}

/* ---------- События ---------- */
function bindEvents() {
  ['pricesForm', 'brandForm', 'textsForm'].forEach((id) => {
    const f = $('#' + id);
    if (f) f.addEventListener('submit', (e) => e.preventDefault());
  });

  // Шапка
  window.addEventListener('scroll', () => { $('#hdr').classList.toggle('scrolled', window.scrollY > 8); }, { passive: true });

  // Калькулятор
  $('#segType').addEventListener('click', (e) => {
    const b = e.target.closest('[data-type]');
    if (!b) return;
    state.type = b.dataset.type;
    state.size = 0;
    renderTypeSeg();
    renderDyn();
    updatePrice();
  });
  $('#segDirt').addEventListener('click', (e) => {
    const b = e.target.closest('[data-dirt]');
    if (!b) return;
    state.dirt = Number(b.dataset.dirt);
    renderDirtSeg();
    updatePrice();
  });
  $('#stains').addEventListener('click', (e) => {
    const b = e.target.closest('[data-stain]');
    if (!b) return;
    const k = b.dataset.stain;
    if (state.stains.has(k)) state.stains.delete(k); else state.stains.add(k);
    b.setAttribute('aria-pressed', String(state.stains.has(k)));
    updatePrice();
  });
  $('#dyn').addEventListener('click', (e) => {
    const b = e.target.closest('[data-size]');
    if (!b) return;
    state.size = Number(b.dataset.size);
    renderDyn();
    updatePrice();
  });
  $('#dyn').addEventListener('input', (e) => {
    if (e.target.id === 'cl') state.CL = Math.max(0.5, num(e.target.value, 0.5));
    if (e.target.id === 'cw') state.CW = Math.max(0.5, num(e.target.value, 0.5));
    if (e.target.id === 'dm') state.dims = e.target.value;
    updatePrice();
  });
  $('#qty').addEventListener('input', () => {
    state.qty = Math.max(1, Math.min(20, Math.round(num($('#qty').value, 1))));
    updatePrice();
  });
  $('#qm').addEventListener('click', () => { state.qty = Math.max(1, state.qty - 1); $('#qty').value = state.qty; updatePrice(); });
  $('#qp').addEventListener('click', () => { state.qty = Math.min(20, state.qty + 1); $('#qty').value = state.qty; updatePrice(); });

  // Телефон
  $('#phone').addEventListener('input', (e) => {
    const pos = e.target.selectionStart;
    const masked = maskPhone(e.target.value);
    e.target.value = masked;
    if (pos !== masked.length) { try { e.target.setSelectionRange(masked.length, masked.length); } catch (err) {} }
  });
  $('#phone').addEventListener('blur', () => { if (digits($('#phone').value).length === 11) fieldError('phone', ''); });

  // Фото
  $('#media').addEventListener('change', async (e) => { await takeFiles(e.target.files); e.target.value = ''; });
  $('#chips').addEventListener('click', (e) => {
    const b = e.target.closest('[data-rm]');
    if (!b) return;
    media.splice(Number(b.dataset.rm), 1);
    renderMediaChips();
  });
  const drop = $('#drop');
  ['dragenter', 'dragover'].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.add('drag'); }));
  ['dragleave', 'drop'].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.remove('drag'); }));
  drop.addEventListener('drop', (e) => { if (e.dataTransfer) takeFiles(e.dataTransfer.files); });

  // Согласие
  $('#agree').addEventListener('change', () => { if ($('#agree').checked) fieldError('agree', ''); });

  // Отправка
  $('#form').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    const btn = $('#submitBtn');
    btn.disabled = true;
    const old = btn.textContent;
    btn.textContent = 'Отправляем…';
    const lead = newLeadFromForm();
    try {
      await store.putLead(lead);
      leads.unshift(lead);
      renderLeads();
      showSuccess(lead);
      resetForm();
      toast('Заявка сохранена');
      notifyLead(lead).then(async (res) => {
        if (res.length) { lead.delivery = res; try { await store.putLead(lead); } catch (e) {} }
      }).catch(() => {});
    } catch (err) {
      toast('Не получилось сохранить заявку. Попробуйте ещё раз.');
    } finally {
      btn.disabled = false;
      btn.textContent = old;
    }
  });
  $('#again').addEventListener('click', hideSuccess);

  // Политика / кабинет
  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-policy]')) { e.preventDefault(); openPolicy(); }
    if (e.target.closest('[data-admin]')) {
      e.preventDefault();
      if (location.hash.indexOf('#admin') === 0) {
        if (settings.security.pin && !authorized) showPinGate('leads');
        else openAdmin('leads');
      } else {
        location.hash = 'admin/leads';
      }
    }
  });

  // демо-подсказка в кабинете
  try {
    if (localStorage.getItem('nc5_demo_note') === '1') $('#demoNote').hidden = true;
  } catch (e) {}
  $('#demoNoteClose').addEventListener('click', () => {
    $('#demoNote').hidden = true;
    try { localStorage.setItem('nc5_demo_note', '1'); } catch (e) {}
  });

  // Работы: сравнение до/после
  $('#worksList').addEventListener('input', (e) => {
    const r = e.target;
    if (r.matches('.cmp input[type=range]')) r.closest('.cmp').style.setProperty('--p', r.value + '%');
  });

  // Админка: вкладки
  $('#tabs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tab]');
    if (b) setTab(b.dataset.tab);
  });
  $('#toSite').addEventListener('click', () => { location.hash = 'top'; openSite(false); window.scrollTo(0, 0); });

  // Поиск и фильтры
  $('#q').addEventListener('input', (e) => { searchQuery = e.target.value; renderLeads(); });
  $('#filterStatus').addEventListener('change', (e) => { statusFilter = e.target.value; renderLeads(); });
  $('#viewSeg').addEventListener('click', (e) => {
    const b = e.target.closest('[data-view]');
    if (!b) return;
    adminView = b.dataset.view;
    $$('#viewSeg button').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
    renderLeads();
  });
  $('#newLead').addEventListener('click', () => openLead(null));

  // Клик по заявке
  $('#leadsView').addEventListener('click', (e) => {
    const edit = e.target.closest('[data-edit]');
    if (edit) { openLead(edit.dataset.edit); return; }
    const ph = e.target.closest('[data-photos]');
    if (ph) { openLead(ph.dataset.photos); return; }
    if (e.target.closest('a')) return;
    const row = e.target.closest('tr[data-id]');
    if (row) openLead(row.dataset.id);
  });

  // Доска: drag&drop
  $('#leadsView').addEventListener('dragstart', (e) => {
    const card = e.target.closest('.kcard');
    if (!card) return;
    e.dataTransfer.setData('text/plain', card.dataset.id);
    card.classList.add('drag');
  });
  $('#leadsView').addEventListener('dragend', (e) => {
    const card = e.target.closest('.kcard');
    if (card) card.classList.remove('drag');
  });
  $('#leadsView').addEventListener('dragover', (e) => {
    const col = e.target.closest('.kcol');
    if (!col) return;
    e.preventDefault();
    $$('.kcol').forEach((c) => c.classList.toggle('over', c === col));
  });
  $('#leadsView').addEventListener('drop', async (e) => {
    const col = e.target.closest('.kcol');
    if (!col) return;
    e.preventDefault();
    $$('.kcol').forEach((c) => c.classList.remove('over'));
    const id = e.dataTransfer.getData('text/plain');
    const lead = leads.find((l) => String(l.id) === String(id));
    if (!lead) return;
    const status = col.dataset.status;
    if (lead.status === status) return;
    const prev = lead.status;
    lead.status = status;
    await store.putLead(lead);
    renderLeads();
    toast('Статус: ' + status, { label: 'Отменить', run: async () => { lead.status = prev; await store.putLead(lead); renderLeads(); } });
  });

  // Настройки: автосохранение
  document.addEventListener('input', (e) => {
    const el = e.target.closest('[data-set],[data-txt],[data-edit]');
    if (!el) return;
    let path = el.dataset.set;
    if (el.dataset.txt) path = 'texts.' + el.dataset.txt;
    if (el.dataset.edit) path = el.dataset.edit;
    if (!path) return;
    let value = el.value;
    if (el.type === 'number') value = num(value, 0);
    setPath(settings, path, value);
    scheduleSave();
    if (path.indexOf('brand.') === 0) { applyBrand(); renderBrandPreview(); }
    else if (path.indexOf('prices.') === 0 || path.indexOf('cfg.') === 0) { renderPrices(); updatePrice(); renderCalcExample(); }
    else if (path.indexOf('texts.') === 0) { applyTexts(); }
  });
  document.addEventListener('change', (e) => {
    const el = e.target.closest('[data-set]');
    if (el && el.type === 'color') { applyAll(); }
  });

  // Удаление отзывов/вопросов
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-del]');
    if (!b) return;
    const [list, idx] = b.dataset.del.split('.');
    if (Array.isArray(settings.texts[list])) {
      settings.texts[list].splice(Number(idx), 1);
      renderEditors();
      applyAll();
      persistSettings();
    }
  });

  $('#addReview').addEventListener('click', () => {
    settings.texts.reviews.push({ n: 'Имя клиента', t: '' });
    renderEditors(); applyAll(); persistSettings();
  });
  $('#addFaq').addEventListener('click', () => {
    settings.texts.faq.push({ q: 'Новый вопрос', a: '' });
    renderEditors(); applyAll(); persistSettings();
  });
  $('#resetTexts').addEventListener('click', () => {
    if (!confirm('Вернуть демо-тексты?')) return;
    settings.texts = clone(DEFAULT_SETTINGS.texts);
    bindSettingsForms(); applyAll(); persistSettings(); toast('Тексты сброшены');
  });

  // Бренд: логотип и код
  $('#b_logo').addEventListener('change', async (e) => {
    const f = e.target.files[0];
    if (!f) return;
    const src = await compressImage(f, 300, 0.85);
    if (!src) { toast('Не удалось прочитать логотип'); return; }
    settings.brand.logo = src;
    applyAll(); persistSettings(); toast('Логотип обновлён');
    e.target.value = '';
  });
  $('#b_pin').addEventListener('change', async (e) => {
    const v = e.target.value.replace(/\D/g, '').slice(0, 4);
    e.target.value = '';
    if (!v) return;
    if (v.length !== 4) { toast('Код должен быть из 4 цифр'); return; }
    settings.security.pin = await hashPin(v);
    authorized = true;
    persistSettings();
    applyDemoVisibility();
    toast('Код входа включён');
  });
  $('#clearPin').addEventListener('click', () => {
    settings.security.pin = '';
    persistSettings();
    applyDemoVisibility();
    toast('Код входа отключён');
  });

  // Фото сайта
  $('#fHero').addEventListener('change', async (e) => {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    const src = await compressImage(f, 1400, 0.8);
    if (!src) { toast('Не удалось прочитать фото'); return; }
    settings.photos.hero = src;
    await persistPhotos(); renderPhotos(); applyAll(); toast('Фото первого экрана обновлено');
  });
  $('#fBanner').addEventListener('change', async (e) => {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    const src = await compressImage(f, 1600, 0.8);
    if (!src) { toast('Не удалось прочитать фото'); return; }
    settings.photos.banner = src;
    await persistPhotos(); renderPhotos(); applyAll(); toast('Баннер обновлён');
  });
  $('#rHero').addEventListener('click', async () => { settings.photos.hero = ''; await persistPhotos(); renderPhotos(); applyAll(); toast('Исходное фото возвращено'); });
  $('#rBanner').addEventListener('click', async () => { settings.photos.banner = ''; await persistPhotos(); renderPhotos(); applyAll(); toast('Исходный баннер возвращён'); });

  // Галерея
  $('#galleryList').addEventListener('input', (e) => {
    const inp = e.target.closest('[data-cap]');
    if (!inp) return;
    const items = galleryItems();
    items[Number(inp.dataset.cap)].cap = inp.value;
    settings.photos.gallery = items;
    schedulePhotosSave(); renderWorks();
  });
  $('#galleryList').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-move],[data-delwork]');
    if (!b) return;
    const items = galleryItems().slice();
    const row = b.closest('.pli');
    const i = Number(row.dataset.i);
    if (b.dataset.delwork !== undefined) {
      if (!confirm('Удалить эту работу из галереи?')) return;
      items.splice(i, 1);
    } else {
      const j = i + Number(b.dataset.move);
      if (j < 0 || j >= items.length) return;
      const tmp = items[i]; items[i] = items[j]; items[j] = tmp;
    }
    settings.photos.gallery = items;
    await persistPhotos(); renderPhotos(); renderWorks();
  });

  $('#addWork').addEventListener('submit', async (e) => {
    e.preventDefault();
    const cap = $('#wCap').value.trim() || 'Работа';
    const mode = $('#wType').value;
    const fb = $('#wBefore').files[0];
    const fa = $('#wAfter').files[0];
    if (!fb || (mode === 'pair' && !fa)) { toast('Выберите фото'); return; }
    const before = await compressImage(fb, 1200, 0.78);
    const after = mode === 'pair' ? await compressImage(fa, 1200, 0.78) : '';
    if (!before || (mode === 'pair' && !after)) { toast('Не удалось прочитать фото'); return; }
    const items = galleryItems().slice();
    items.push({ id: 'g' + Date.now(), mode, before, after, cap });
    settings.photos.gallery = items;
    await persistPhotos();
    renderPhotos(); renderWorks();
    e.target.reset();
    toast('Работа добавлена');
  });

  // Видео
  $('#fVideo').addEventListener('change', async (e) => {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    if (f.size > 80 * 1048576) { toast('Видео больше 80 МБ — сожмите его'); return; }
    try {
      await store.putVideo(f);
      await applyVideo();
      toast('Видео добавлено на сайт');
    } catch (err) { toast('Браузер не дал сохранить видео'); }
  });
  $('#rVideo').addEventListener('click', async () => {
    try { await store.delVideo(); } catch (e) {}
    await applyVideo();
    toast('Видео удалено');
  });

  // Данные
  $('#exportJson').addEventListener('click', downloadBackup);
  $('#exportCsv').addEventListener('click', exportCsv);
  $('#importFile').addEventListener('change', async (e) => {
    const f = e.target.files[0]; e.target.value = '';
    if (f) await importBackup(f);
  });
  $('#testNotify').addEventListener('click', async () => {
    if (!NC_DELIVERY.telegram.token && !NC_DELIVERY.email.endpoint) {
      toast('Заполните NC_DELIVERY в начале скрипта');
      return;
    }
    const res = await notifyLead({ name: 'Проверка', phone: settings.brand.phone, contact: '—', addr: '—', service: 'Тестовое сообщение', price: 0, high: 0, comment: 'Это проверка уведомлений' });
    toast(res.every((r) => r.ok) ? 'Уведомление отправлено' : 'Не удалось отправить');
  });
  $('#resetLeads').addEventListener('click', async () => {
    if (!confirm('Удалить все заявки? Действие можно отменить только из резервной копии.')) return;
    await store.clearLeads();
    leads = [];
    renderLeads();
    toast('Заявки очищены');
  });
  $('#resetAll').addEventListener('click', async () => {
    if (!confirm('Сбросить всё к демо-состоянию? Текущие заявки и настройки будут удалены.')) return;
    settings = clone(DEFAULT_SETTINGS);
    await persistSettings();
    await persistPhotos();
    await store.clearLeads();
    leads = demoLeads();
    for (const l of leads) await store.putLead(l);
    bindSettingsForms(); applyAll(); renderLeads(); renderPhotos(); applyVideo();
    toast('Всё сброшено к демо');
  });

  // Роутинг
  window.addEventListener('hashchange', route);

  // Горячие клавиши в кабинете
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && document.body.classList.contains('admin-mode') && !$('#modalRoot').innerHTML) {
      location.hash = 'top';
    }
  });
}

function openWork(id) {
  const item = galleryItems().find((g) => String(g.id) === String(id));
  if (!item) return;
  const before = resolveImg(item.before);
  const after = resolveImg(item.after);
  const html = item.mode === 'pair' && after
    ? `<div class="lb" data-close><div class="lb-pair"><img src="${esc(before)}" alt="До"><img src="${esc(after)}" alt="После"></div><button class="lb-close" type="button" aria-label="Закрыть">✕</button></div>`
    : `<div class="lb" data-close><img src="${esc(before)}" alt="${esc(item.cap)}"><button class="lb-close" type="button" aria-label="Закрыть">✕</button></div>`;
  const root = document.getElementById('modalRoot');
  root.innerHTML = html;
  const back = root.querySelector('[data-close]');
  const close = () => { root.innerHTML = ''; document.removeEventListener('keydown', onKey); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  back.addEventListener('click', (e) => { if (e.target === back || e.target.closest('.lb-close')) close(); });
  document.addEventListener('keydown', onKey);
}

/* ---------- Инициализация ---------- */
async function init() {
  await store.init();

  const savedSettings = await store.getSettings();
  if (savedSettings) settings = deepMerge(settings, savedSettings);
  const savedPhotos = await store.getPhotos();
  if (savedPhotos) settings.photos = deepMerge(settings.photos, savedPhotos);

  await migrateV4();

  leads = await store.getAllLeads();
  if (!leads.length && !(await store.getMeta('seeded'))) {
    leads = demoLeads();
    for (const l of leads) await store.putLead(l);
    await store.setMeta('seeded', 1);
  }
  leads.sort((a, b) => (Number(b.createdAt) || 0) - (Number(a.createdAt) || 0));

  $('#year').textContent = new Date().getFullYear();

  renderCalc();
  applyAll();
  bindSettingsForms();
  bindEvents();
  renderMediaChips();
  renderLeads();
  renderPhotos();
  applyVideo();

  if (store.mode === 'ls') {
    setSaveState('error');
    $('#saveState').textContent = 'Режим совместимости';
    console.warn('IndexedDB недоступен, используется localStorage');
  }

  await route();
}

init().catch((err) => {
  console.error(err);
  const t = document.getElementById('toast');
  if (t) { t.textContent = 'Ошибка запуска: ' + err.message; t.classList.add('on'); }
});

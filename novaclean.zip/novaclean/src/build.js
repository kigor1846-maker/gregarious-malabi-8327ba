const fs = require('fs');
const path = require('path');

const src = path.join(__dirname);
const opt = path.join(__dirname, '..', '.tools', 'opt');
const out = path.join(__dirname, '..', 'NovaClean-v5.html');

const read = (f) => fs.readFileSync(path.join(src, f), 'utf8');
const img = (f) => 'data:image/jpeg;base64,' + fs.readFileSync(path.join(opt, f)).toString('base64');

let html = read('index.html');
const css = read('styles.css');
const js = read('app.js');

const map = {
  CSS: css,
  JS: js,
  IMG_HERO: img('hero.jpg'),
  IMG_BANNER: img('banner.jpg'),
  IMG_A1: img('a1.jpg'),
  IMG_A2: img('a2.jpg'),
  IMG_B1: img('b1.jpg'),
  IMG_B2: img('b2.jpg')
};

html = html.replace(/\{\{([A-Z0-9_]+)\}\}/g, (m, key) => (map[key] !== undefined ? map[key] : m));
// второй проход — для плейсхолдеров внутри вставленного JS
html = html.replace(/\{\{([A-Z0-9_]+)\}\}/g, (m, key) => (map[key] !== undefined ? map[key] : m));

const left = html.match(/\{\{[A-Z0-9_]+\}\}/g);
if (left) {
  console.error('Не заменены плейсхолдеры:', left);
  process.exit(1);
}

fs.writeFileSync(out, html, 'utf8');
console.log('Готово:', out);
console.log('Размер:', (Buffer.byteLength(html, 'utf8') / 1024).toFixed(0) + ' KB');
console.log('CSS:', (Buffer.byteLength(css, 'utf8') / 1024).toFixed(1) + ' KB, JS:', (Buffer.byteLength(js, 'utf8') / 1024).toFixed(1) + ' KB');
